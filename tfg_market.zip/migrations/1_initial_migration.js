const My_NFT = artifacts.require("My_NFT");

module.exports = function (deployer) {
  deployer.deploy(My_NFT);
};
